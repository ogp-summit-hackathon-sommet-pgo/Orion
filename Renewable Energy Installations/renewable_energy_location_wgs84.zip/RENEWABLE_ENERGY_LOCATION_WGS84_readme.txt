RENEWABLE_ENERGY_LOCATION_WGS84_readme
 

Column name  (Description)
======================================
A_ADDRESS = ADDRESS_FULL  (Official Municpal Address within city City of Toronto)
A_EASTING = X
A_NORTHING = Y
LONGITUDE = LONGITUDE
LATITUDE = LATITUDE
R_BUILDING = BUILDING_NAME  (Building name)
R_LOCATION = CLIENT_ADDRESS  (Address for renewable energy project)
R_TYPE = TYPE_INSTALL  (Type of installation (e.g. Solar Pool Heating, Solar Photovoltaic))
R_YR_INSTA = YEAR_INSTALL  (Year installed)
R_SIZE = SIZE_INSTALL  (Size of installation)
R_UNIT = UNIT_MAX_POWER  (Unit of measurement of maximum power)
R_ENERGY_0 = ENERGY_OUTPUT  (Energy output  (ekW))
RUNIT2 = UNIT_ANNUAL  (Unit of measurment for 1 year)
R_LANDLORD = LANDLORD  (City of Toronto landlord)
R_SYS_OWNR = SYSTEM_OWNERSHIP  (System Ownership)
R_CITY_NAM = FORMER_MUNICIPALITY  (Name of former municipality within the amalgamated City of Toronto)
R_OBJECTID = OBJECTID
